using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;

namespace DB_Layan_Eman.Pages
{
    public class SignupModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        [BindProperty]
        public string FullName { get; set; } = string.Empty;
        [BindProperty]
        public string Email { get; set; } = string.Empty;
        [BindProperty]
        public string Password { get; set; } = string.Empty;
        [BindProperty]
        public string UserType { get; set; } = string.Empty;

        public async Task<IActionResult> OnPostAsync()
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "INSERT INTO USERS (FULLNAME, EMAIL, PASSWORD, USER_TYPE) VALUES (:name, :email, :pass, :type)";
                OracleCommand cmd = new OracleCommand(query, con);
                cmd.Parameters.Add(new OracleParameter("name", FullName));
                cmd.Parameters.Add(new OracleParameter("email", Email));
                cmd.Parameters.Add(new OracleParameter("pass", Password));
                cmd.Parameters.Add(new OracleParameter("type", UserType));

                await con.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
            return RedirectToPage("/Login");
        }
    }
}