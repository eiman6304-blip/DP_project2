﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TableGo.Pages
{
    public class Manage_ResModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        [BindProperty] public RestaurantDetail CurrentRestaurant { get; set; } = new();
        [BindProperty] public int SelectedTableId { get; set; }
        [BindProperty] public int NewCapacity { get; set; }
        [BindProperty] public int AddTableCapacity { get; set; }

        public List<TableDetail> Tables { get; set; } = new();
        public List<ReservationDetail> Reservations { get; set; } = new();

        public class RestaurantDetail
        {
            public int Id { get; set; }
            public string Name { get; set; } = "";
            public string Location { get; set; } = "";
            public string Cuisine { get; set; } = "";
            public string Phone { get; set; } = "";
            public string ImageUrl { get; set; } = "";
        }

        public class TableDetail
        {
            public int TableId { get; set; }
            public int Capacity { get; set; }
            public string Status { get; set; } = "";
        }

        public class ReservationDetail
        {
            public string CustomerName { get; set; } = "";
            public string TableId { get; set; } = "";
            public string ResDate { get; set; } = "";
            public string Status { get; set; } = "";
        }

        public void OnGet(int? resId)
        {
            if (resId == null)
            {
                string? idFromQuery = Request.Query["resId"];
                if (!string.IsNullOrEmpty(idFromQuery))
                {
                    resId = int.Parse(idFromQuery);
                }
            }

            if (resId != null)
            {
                LoadData(resId.Value);
            }
        }

        // 1. تحديث معلومات المطعم
        public IActionResult OnPostUpdateInfo()
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "UPDATE RESTAURANTS SET NAME=:name, LOCATION=:loc, CUISINE=:cui, PHONE_NUMBER=:ph, IMAGE_URL=:img WHERE RES_ID=:id";
                OracleCommand cmd = new OracleCommand(query, con);
                cmd.Parameters.Add(new OracleParameter("name", CurrentRestaurant.Name));
                cmd.Parameters.Add(new OracleParameter("loc", CurrentRestaurant.Location));
                cmd.Parameters.Add(new OracleParameter("cui", CurrentRestaurant.Cuisine));
                cmd.Parameters.Add(new OracleParameter("ph", CurrentRestaurant.Phone));
                cmd.Parameters.Add(new OracleParameter("img", CurrentRestaurant.ImageUrl));
                cmd.Parameters.Add(new OracleParameter("id", CurrentRestaurant.Id));
                con.Open();
                cmd.ExecuteNonQuery();
            }
            return RedirectToPage(new { resId = CurrentRestaurant.Id });
        }

        // 2. حذف المطعم نهائياً مع تنظيف كل السجلات المرتبطة به لتفادي مشاكل الـ Constraints
        public IActionResult OnPostDeleteRestaurant()
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                con.Open();
                using (OracleTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // أ. حذف الحجوزات المرتبطة بالمطعم أولاً (حيث R_ID أو عبر طاولات المطعم)
                        string deleteReservations = "DELETE FROM RESERVATION WHERE TRIM(R_ID) = TRIM(:id)";
                        using (OracleCommand cmd = new OracleCommand(deleteReservations, con))
                        {
                            cmd.Parameters.Add(new OracleParameter("id", CurrentRestaurant.Id));
                            cmd.ExecuteNonQuery();
                        }

                        // ب. حذف الطاولات المرتبطة بالمطعم
                        string deleteTables = "DELETE FROM TABLES WHERE RES_ID = :id";
                        using (OracleCommand cmd = new OracleCommand(deleteTables, con))
                        {
                            cmd.Parameters.Add(new OracleParameter("id", CurrentRestaurant.Id));
                            cmd.ExecuteNonQuery();
                        }

                        // ج. حذف المطعم نفسه الآن بأمان
                        string deleteRestaurant = "DELETE FROM RESTAURANTS WHERE RES_ID = :id";
                        using (OracleCommand cmd = new OracleCommand(deleteRestaurant, con))
                        {
                            cmd.Parameters.Add(new OracleParameter("id", CurrentRestaurant.Id));
                            cmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        return RedirectToPage("/Cards");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ModelState.AddModelError(string.Empty, $"خطأ أثناء حذف المطعم ومرفقاته: {ex.Message}");
                        LoadData(CurrentRestaurant.Id);
                        return Page();
                    }
                }
            }
        }

        // 3. تحديث سعة الطاولة
        public IActionResult OnPostUpdateTable()
        {
            string? idFromQuery = Request.Query["resId"];
            if (string.IsNullOrEmpty(idFromQuery)) return RedirectToPage("/Cards");

            int resId = int.Parse(idFromQuery);

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "UPDATE TABLES SET CAPACITY = :cap WHERE T_ID = :tid";
                OracleCommand cmd = new OracleCommand(query, con);
                cmd.Parameters.Add(new OracleParameter("cap", NewCapacity));
                cmd.Parameters.Add(new OracleParameter("tid", SelectedTableId));
                con.Open();
                cmd.ExecuteNonQuery();
            }

            return RedirectToPage(new { resId = resId });
        }

        // 4. إضافة طاولة جديدة للمطعم
        public IActionResult OnPostAddTable()
        {
            string? idFromQuery = Request.Query["resId"];
            if (string.IsNullOrEmpty(idFromQuery)) return RedirectToPage("/Cards");

            int resId = int.Parse(idFromQuery);

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "INSERT INTO TABLES (T_ID, RES_ID, CAPACITY, STATUS) " +
                               "VALUES ((SELECT NVL(MAX(T_ID), 0) + 1 FROM TABLES), :resId, :cap, 'AVAILABLE')";

                using (OracleCommand cmd = new OracleCommand(query, con))
                {
                    cmd.BindByName = true;
                    cmd.Parameters.Add(new OracleParameter("resId", resId));
                    cmd.Parameters.Add(new OracleParameter("cap", AddTableCapacity));

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToPage(new { resId = resId });
        }

        // 5. حذف طاولة معينة بعد مسح حجوزاتها التابعة لها تفادياً للـ Constraint
        public IActionResult OnPostDeleteTable(int tableId, int? resId)
        {
            if (resId == null)
            {
                string? idFromQuery = Request.Query["resId"];
                if (!string.IsNullOrEmpty(idFromQuery))
                {
                    resId = int.Parse(idFromQuery);
                }
            }

            if (resId == null) return RedirectToPage("/Cards");

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                con.Open();
                using (OracleTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // أ. حذف الحجوزات المرتبطة بهذه الطاولة أولاً
                        string deleteTableReservations = "DELETE FROM RESERVATION WHERE T_ID = :tid";
                        using (OracleCommand cmd = new OracleCommand(deleteTableReservations, con))
                        {
                            cmd.Parameters.Add(new OracleParameter("tid", tableId));
                            cmd.ExecuteNonQuery();
                        }

                        // ب. حذف الطاولة نفسها
                        string deleteTable = "DELETE FROM TABLES WHERE T_ID = :tid";
                        using (OracleCommand cmd = new OracleCommand(deleteTable, con))
                        {
                            cmd.Parameters.Add(new OracleParameter("tid", tableId));
                            cmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ModelState.AddModelError(string.Empty, $"خطأ أثناء حذف الطاولة وحجوزاتها: {ex.Message}");
                        LoadData(resId.Value);
                        return Page();
                    }
                }
            }

            return RedirectToPage(new { resId = resId.Value });
        }

        private void LoadData(int resId)
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                con.Open();

                // 1. جلب المطعم
                OracleCommand cmdRes = new OracleCommand("SELECT RES_ID, NAME, LOCATION, CUISINE, PHONE_NUMBER, IMAGE_Path FROM RESTAURANTS WHERE RES_ID = :id", con);
                cmdRes.Parameters.Add(new OracleParameter("id", resId));
                using (OracleDataReader r = cmdRes.ExecuteReader())
                {
                    if (r.Read())
                    {
                        CurrentRestaurant = new RestaurantDetail
                        {
                            Id = resId,
                            Name = r["NAME"]?.ToString() ?? "",
                            Location = r["LOCATION"]?.ToString() ?? "",
                            Cuisine = r["CUISINE"]?.ToString() ?? "",
                            Phone = r["PHONE_NUMBER"]?.ToString() ?? "",
                            ImageUrl = r["IMAGE_Path"]?.ToString() ?? ""
                        };
                    }
                }

                // 2. جلب الطاولات
                OracleCommand cmdTabs = new OracleCommand("SELECT T_ID, CAPACITY, STATUS FROM TABLES WHERE RES_ID = :id ORDER BY T_ID", con);
                cmdTabs.Parameters.Add(new OracleParameter("id", resId));
                using (OracleDataReader r = cmdTabs.ExecuteReader())
                {
                    while (r.Read())
                    {
                        Tables.Add(new TableDetail
                        {
                            TableId = Convert.ToInt32(r["T_ID"]),
                            Capacity = Convert.ToInt32(r["CAPACITY"]),
                            Status = r["STATUS"]?.ToString() ?? "AVAILABLE"
                        });
                    }
                }

                // 3. جلب الحجوزات
                string resQuery = @"SELECT CUSTOMER_NAME, T_ID, 
                                           TO_CHAR(RESERVATIONDATE, 'YYYY-MM-DD HH24:MI') AS RES_DATE
                                    FROM RESERVATION 
                                    WHERE TRIM(R_ID) = TRIM(:id)";

                using (OracleCommand cmdReserv = new OracleCommand(resQuery, con))
                {
                    cmdReserv.Parameters.Add(new OracleParameter("id", Convert.ToInt32(resId)));

                    try
                    {
                        using (OracleDataReader r = cmdReserv.ExecuteReader())
                        {
                            int customerNameIdx = r.GetOrdinal("CUSTOMER_NAME");
                            int tIdIdx = r.GetOrdinal("T_ID");
                            int resDateIdx = r.GetOrdinal("RES_DATE");

                            while (r.Read())
                            {
                                Reservations.Add(new ReservationDetail
                                {
                                    CustomerName = !r.IsDBNull(customerNameIdx) ? r.GetString(customerNameIdx) : "N/A",
                                    TableId = !r.IsDBNull(tIdIdx) ? r.GetValue(tIdIdx).ToString()! : "N/A",
                                    ResDate = !r.IsDBNull(resDateIdx) ? r.GetString(resDateIdx) : "N/A"
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Reservations.Add(new ReservationDetail
                        {
                            CustomerName = "⚠️ خطأ في الاستعلام أو أسماء الأعمدة:",
                            TableId = "ERR",
                            ResDate = ex.Message,
                            Status = "ERROR"
                        });
                    }
                }
            }
        }
    }
}