using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DB_Layan_Eman.Pages
{
    public class MyBookingsModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        public string? UserName { get; set; }
        public string? UserType { get; set; }
        public string? UserId { get; set; }

        public List<UserReservation> MyReservations { get; set; } = new List<UserReservation>();

        [TempData]
        public string? SuccessMessage { get; set; }
        [TempData]
        public string? ErrorMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            UserName = HttpContext.Session.GetString("UserName");
            UserType = HttpContext.Session.GetString("UserType");
            UserId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(UserId))
            {
                return RedirectToPage("/Login");
            }

            await LoadReservationsAsync();
            return Page();
        }

        private async Task LoadReservationsAsync()
        {
            // ��� ����� �� ������� ����� ��� ����� ������ ����� �������
            var sessionUserId = HttpContext.Session.GetString("UserId");
            if (!int.TryParse(sessionUserId, out int numericUserId))
            {
                System.Diagnostics.Debug.WriteLine("[TableGo Warning] UserId is not a valid number.");
                return;
            }

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                // ��������� ������� (����� ������ RESERVATION)
                string query = @"
                    SELECT 
                        r.RERESERVATION_ID  AS RES_ID_PK, 
                        r.R_ID             AS REST_ID_FK, 
                        r.T_ID             AS TABLE_ID_FK, 
                        r.GUESTCOUNT       AS GUEST_CNT, 
                        r.RESERVATIONDATE  AS RES_DATE, 
                        r.CUSTOMER_NAME    AS CUST_NAME, 
                        res.NAME           AS REST_NAME,
                        res.IMAGE_URL      AS REST_IMG
                    FROM RESERVATION r
                    LEFT JOIN RESTAURANTS res ON r.R_ID = res.RES_ID
                    WHERE r.USER_ID = :userId
                    ORDER BY r.RESERVATIONDATE DESC";

                // ������� ���� (����� ����� RESERVATIONS) �� ��� ��� ��� ������ ����� �� ��� DB
                string fallbackQuery = @"
                    SELECT 
                        r.RERESERVATION_ID  AS RES_ID_PK, 
                        r.R_ID             AS REST_ID_FK, 
                        r.T_ID             AS TABLE_ID_FK, 
                        r.GUESTCOUNT       AS GUEST_CNT, 
                        r.RESERVATIONDATE  AS RES_DATE, 
                        r.CUSTOMER_NAME    AS CUST_NAME, 
                        res.NAME           AS REST_NAME,
                        res.IMAGE_URL      AS REST_IMG
                    FROM RESERVATION r
                    LEFT JOIN RESTAURANTS res ON r.R_ID = res.RES_ID
                    WHERE r.USER_ID = :userId
                    ORDER BY r.RESERVATIONDATE DESC";

                try
                {
                    await con.OpenAsync();
                    bool success = await ExecuteFetchQueryAsync(con, query, numericUserId);

                    // ��� ��� ��������� ����� ���� ��� ������ ��� ������ ����� ������
                    if (!success)
                    {
                        await ExecuteFetchQueryAsync(con, fallbackQuery, numericUserId);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error Loading Bookings: " + ex.Message);
                    ErrorMessage = "Error loading bookings from database.";
                }
            }
        }

        // ���� ������ ������ ��� �������� ����� ����� �����
        private async Task<bool> ExecuteFetchQueryAsync(OracleConnection con, string sqlQuery, int userId)
        {
            // ����� ������� ��������� ������� �� ����� ������� ��� RESERVATION_ID
            // ����� �� ��� ����� �� ����� RESERVATION_ID �� RERESERVATION_ID� ����� �� ���� ������� �� ������ �������
            string fixedQuery = sqlQuery.Replace("r.RERESERVATION_ID", "r.RESERVATION_ID");

            using (OracleCommand cmd = new OracleCommand(fixedQuery, con))
            {
                cmd.BindByName = true;
                cmd.Parameters.Add(new OracleParameter("userId", userId));

                try
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        MyReservations.Clear(); // ����� ������� ��� �������
                        while (await reader.ReadAsync())
                        {
                            MyReservations.Add(new UserReservation
                            {
                                ReservationId = reader["RES_ID_PK"] != DBNull.Value ? Convert.ToInt32(reader["RES_ID_PK"]) : 0,
                                RestaurantId = reader["REST_ID_FK"] != DBNull.Value ? Convert.ToInt32(reader["REST_ID_FK"]) : 0,
                                TableId = reader["TABLE_ID_FK"] != DBNull.Value ? Convert.ToInt32(reader["TABLE_ID_FK"]) : 0,
                                GuestCount = reader["GUEST_CNT"] != DBNull.Value ? Convert.ToInt32(reader["GUEST_CNT"]) : 0,
                                ReservationDate = reader["RES_DATE"] != DBNull.Value ? Convert.ToDateTime(reader["RES_DATE"]) : DateTime.Now,
                                CustomerName = reader["CUST_NAME"] != DBNull.Value ? reader["CUST_NAME"].ToString() ?? "" : "",
                                RestaurantName = reader["REST_NAME"] != DBNull.Value ? reader["REST_NAME"].ToString() ?? "Unknown Restaurant" : "Unknown Restaurant",
                                ImageUrl = reader["REST_IMG"] != DBNull.Value && !string.IsNullOrEmpty(reader["REST_IMG"].ToString())
                                    ? reader["REST_IMG"].ToString()!
                                    : "https://images.unsplash.com/photo-1555396273-367ea4eb4db5"
                            });
                        }
                    }
                    return true;
                }
                catch (OracleException ex) when (ex.Number == 942)
                {
                    // ��� ������ ��� ����ϡ ����� false ������ ��������� ������
                    return false;
                }
            }
        }

        public async Task<IActionResult> OnPostUpdateAsync(int reservationId, DateTime newDate, int newGuests)
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                // ����� ����� �� ����� ��� ������� ������
                string query = "UPDATE RESERVATION SET RESERVATIONDATE = :resDate, GUESTCOUNT = :guests WHERE RESERVATION_ID = :resId";
                string fallbackQuery = "UPDATE RESERVATION SET RESERVATIONDATE = :resDate, GUESTCOUNT = :guests WHERE RESERVATION_ID = :resId";

                try
                {
                    await con.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand(query, con))
                    {
                        cmd.BindByName = true;
                        cmd.Parameters.Add(new OracleParameter("resDate", newDate));
                        cmd.Parameters.Add(new OracleParameter("guests", newGuests));
                        cmd.Parameters.Add(new OracleParameter("resId", reservationId));

                        int rows = await cmd.ExecuteNonQueryAsync();
                        if (rows > 0) SuccessMessage = "Booking updated successfully!";
                        else ErrorMessage = "Failed to update booking.";
                    }
                }
                catch (OracleException ex) when (ex.Number == 942)
                {
                    // ��� ���� �����
                    using (OracleCommand cmd = new OracleCommand(fallbackQuery, con))
                    {
                        cmd.BindByName = true;
                        cmd.Parameters.Add(new OracleParameter("resDate", newDate));
                        cmd.Parameters.Add(new OracleParameter("guests", newGuests));
                        cmd.Parameters.Add(new OracleParameter("resId", reservationId));

                        int rows = await cmd.ExecuteNonQueryAsync();
                        if (rows > 0) SuccessMessage = "Booking updated successfully!";
                        else ErrorMessage = "Failed to update booking.";
                    }
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Error: " + ex.Message;
                }
            }
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int reservationId)
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                try
                {
                    await con.OpenAsync();
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Connection error: " + ex.Message;
                    return RedirectToPage();
                }

                using (OracleTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        int tableId = 0;
                        // ������ ��� ��� ������� �� RESERVATION �� RESERVATIONS
                        string findTableQuery = "SELECT T_ID FROM RESERVATION WHERE RESERVATION_ID = :resId";
                        try
                        {
                            using (OracleCommand cmdFind = new OracleCommand(findTableQuery, con))
                            {
                                cmdFind.BindByName = true;
                                cmdFind.Parameters.Add(new OracleParameter("resId", reservationId));
                                object result = await cmdFind.ExecuteScalarAsync();
                                if (result != null && result != DBNull.Value) tableId = Convert.ToInt32(result);
                            }
                        }
                        catch
                        {
                            string findTableQueryFallback = "SELECT T_ID FROM RESERVATION WHERE RESERVATION_ID = :resId";
                            using (OracleCommand cmdFind = new OracleCommand(findTableQueryFallback, con))
                            {
                                cmdFind.BindByName = true;
                                cmdFind.Parameters.Add(new OracleParameter("resId", reservationId));
                                object result = await cmdFind.ExecuteScalarAsync();
                                if (result != null && result != DBNull.Value) tableId = Convert.ToInt32(result);
                            }
                        }

                        // ����� ���� �������
                        if (tableId > 0)
                        {
                            string updateTableQuery = "UPDATE TABLES SET STATUS = 'AVAILABLE' WHERE T_ID = :tableId";
                            using (OracleCommand cmdUpdate = new OracleCommand(updateTableQuery, con))
                            {
                                cmdUpdate.BindByName = true;
                                cmdUpdate.Parameters.Add(new OracleParameter("tableId", tableId));
                                await cmdUpdate.ExecuteNonQueryAsync();
                            }
                        }

                        // ��� �����
                        string deleteQuery = "DELETE FROM RESERVATION WHERE RESERVATION_ID = :resId";
                        int rows = 0;
                        try
                        {
                            using (OracleCommand cmdDelete = new OracleCommand(deleteQuery, con))
                            {
                                cmdDelete.BindByName = true;
                                cmdDelete.Parameters.Add(new OracleParameter("resId", reservationId));
                                rows = await cmdDelete.ExecuteNonQueryAsync();
                            }
                        }
                        catch
                        {
                            string deleteQueryFallback = "DELETE FROM RESERVATIONS WHERE RESERVATION_ID = :resId";
                            using (OracleCommand cmdDelete = new OracleCommand(deleteQueryFallback, con))
                            {
                                cmdDelete.BindByName = true;
                                cmdDelete.Parameters.Add(new OracleParameter("resId", reservationId));
                                rows = await cmdDelete.ExecuteNonQueryAsync();
                            }
                        }

                        if (rows > 0) SuccessMessage = "Booking cancelled successfully.";
                        else ErrorMessage = "Failed to delete booking.";

                        await transaction.CommitAsync();
                    }
                    catch (Exception ex)
                    {
                        await transaction.RollbackAsync();
                        ErrorMessage = "Error during cancellation: " + ex.Message;
                    }
                }
            }
            return RedirectToPage();
        }
    }

    public class UserReservation
    {
        public int ReservationId { get; set; }
        public int RestaurantId { get; set; }
        public int TableId { get; set; }
        public int GuestCount { get; set; }
        public DateTime ReservationDate { get; set; }
        public string CustomerName { get; set; } = "";
        public string RestaurantName { get; set; } = "";
        public string ImageUrl { get; set; } = "";
    }
}