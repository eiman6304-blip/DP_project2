﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;
using System;

namespace DB_Layan_Eman.Pages
{
    public class BookingModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        [BindProperty] public ReservationInput Input { get; set; } = new();
        public RestaurantDetail Restaurant { get; set; } = new();
        public string ErrorMessage { get; set; } = "";

        public class RestaurantDetail
        {
            public int Id { get; set; }
            public string Name { get; set; } = "";
            public string Location { get; set; } = "";
            public string Cuisine { get; set; } = "";
            public string Description { get; set; } = "";
            public string ImageUrl { get; set; } = "";
        }

        public class ReservationInput
        {
            public int ResId { get; set; }
            public int GuestsCount { get; set; }
            public string CustomerName { get; set; } = "";
            public DateTime BookingDate { get; set; } = DateTime.Now;
            public int UserId { get; set; }
        }

        public IActionResult OnGet(int id)
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");
            var sessionUserName = HttpContext.Session.GetString("UserName");

            if (string.IsNullOrEmpty(sessionUserId))
            {
                return RedirectToPage("/Login");
            }

            Input.ResId = id;
            Input.UserId = Convert.ToInt32(sessionUserId);
            Input.CustomerName = sessionUserName ?? "";
            Input.BookingDate = DateTime.Now.AddHours(1);

            LoadRestaurantData(id);
            return Page();
        }

        public IActionResult OnPost()
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(sessionUserId))
            {
                return RedirectToPage("/Login");
            }
            Input.UserId = Convert.ToInt32(sessionUserId);

            // 1. فحص ساعات العمل
            int hour = Input.BookingDate.Hour;
            if (hour >= 1 && hour < 8)
            {
                ErrorMessage = "Sorry, we are closed between 1:00 AM and 8:00 AM.";
                LoadRestaurantData(Input.ResId);
                return Page();
            }

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Database connection failed: " + ex.Message;
                    LoadRestaurantData(Input.ResId);
                    return Page();
                }

                using (var transaction = con.BeginTransaction())
                {
                    try
                    {
                        // 2. البحث عن طاولة متاحة بناءً على حجم الجيست والوقت
                        int tableId = 0;
                        string findTableQuery = @"
                            SELECT T_ID FROM TABLES t
                            WHERE t.RES_ID = :restaurantIdParam 
                            AND UPPER(t.STATUS) = 'AVAILABLE'
                            AND t.CAPACITY >= :guestCountParam
                            AND NOT EXISTS (
                                SELECT 1 FROM RESERVATION r
                                WHERE r.T_ID = t.T_ID
                                AND r.RESERVATIONDATE BETWEEN :reqDateStart AND :reqDateEnd
                            )
                            AND ROWNUM = 1";

                        using (OracleCommand findCmd = new OracleCommand(findTableQuery, con))
                        {
                            findCmd.BindByName = true;
                            findCmd.Parameters.Add(new OracleParameter("restaurantIdParam", Input.ResId));
                            findCmd.Parameters.Add(new OracleParameter("guestCountParam", Input.GuestsCount));
                            findCmd.Parameters.Add(new OracleParameter("reqDateStart", Input.BookingDate.AddHours(-2)));
                            findCmd.Parameters.Add(new OracleParameter("reqDateEnd", Input.BookingDate.AddHours(2)));

                            var result = findCmd.ExecuteScalar();

                            if (result == null || result == DBNull.Value)
                            {
                                ErrorMessage = "No tables available for this specific time or guest count. Please try another time.";
                                LoadRestaurantData(Input.ResId);
                                return Page();
                            }
                            tableId = Convert.ToInt32(result);
                        }

                        // 3. جملة الـ INSERT للحجز (تعديل أسماء الأعمدة لتطابق تماماً صورة الداتا بيس والترتيب الإلزامي)
                        // قمنا بوضع الأعمدة بنفس مسميات الجدول الظاهرة بالصورة وجعلنا ترتيب البارامترات متطابقاً 100%
                        string insertQuery = @"INSERT INTO RESERVATION (RESERVATION_ID, R_ID, T_ID, GUESTCOUNT, RESERVATIONDATE, USER_ID) 
                                             VALUES (res_id_seq.NEXTVAL, :restaurantIdParam, :tableIdParam, :guestCountParam, :bookingDateParam, :userIdParam)";

                        using (OracleCommand cmd = new OracleCommand(insertQuery, con))
                        {
                            cmd.BindByName = true;

                            // الترتيب الصارم للبارامترات كما هو ظاهر بالـ VALUES
                            cmd.Parameters.Add(new OracleParameter("restaurantIdParam", Input.ResId));
                            cmd.Parameters.Add(new OracleParameter("tableIdParam", tableId));
                            cmd.Parameters.Add(new OracleParameter("guestCountParam", Input.GuestsCount));
                            cmd.Parameters.Add(new OracleParameter("bookingDateParam", Input.BookingDate));
                            cmd.Parameters.Add(new OracleParameter("userIdParam", Input.UserId));

                            cmd.ExecuteNonQuery();
                        }

                        // 4. تحديث حالة الطاولة المحجوزة لتصبح Occupied
                        string updateQuery = "UPDATE TABLES SET STATUS = 'Occupied' WHERE T_ID = :tableIdParam";
                        using (OracleCommand updateCmd = new OracleCommand(updateQuery, con))
                        {
                            updateCmd.BindByName = true;
                            updateCmd.Parameters.Add(new OracleParameter("tableIdParam", tableId));
                            updateCmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        return RedirectToPage("MyBookings");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ErrorMessage = "Oracle Error: " + ex.Message;
                        LoadRestaurantData(Input.ResId);
                        return Page();
                    }
                }
            }
        }

        private void LoadRestaurantData(int resId)
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                try
                {
                    con.Open();
                    // تعديل الاستعلام لجلب IMAGE_PATH بدلاً من IMAGE_URL لتطابق جدول RESTAURANTS
                    string query = "SELECT NAME, LOCATION, CUISINE, IMAGE_PATH FROM RESTAURANTS WHERE RES_ID = :restaurantIdParam";
                    using (OracleCommand cmd = new OracleCommand(query, con))
                    {
                        cmd.BindByName = true;
                        cmd.Parameters.Add(new OracleParameter("restaurantIdParam", resId));
                        using (var r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                Restaurant = new RestaurantDetail
                                {
                                    Id = resId,
                                    Name = r[0]?.ToString() ?? "N/A",
                                    Location = r[1]?.ToString() ?? "N/A",
                                    Cuisine = r[2]?.ToString() ?? "N/A",
                                    Description = $"Experience exquisite {r[2]} dining at {r[0]}.",
                                    ImageUrl = r.IsDBNull(3) ? "/images/default.jpg" : r.GetString(3)
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error loading restaurant details: " + ex.Message);
                }
            }
        }
    }
}