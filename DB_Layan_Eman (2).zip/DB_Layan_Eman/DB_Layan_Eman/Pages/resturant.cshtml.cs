using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DB_Layan_Eman.Pages
{
    public class resturantModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
