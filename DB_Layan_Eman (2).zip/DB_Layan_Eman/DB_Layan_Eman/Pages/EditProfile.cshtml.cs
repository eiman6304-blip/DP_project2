using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace DB_Layan_Eman.Pages
{
    public class EditProfileModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        // ������� ������� ����� ��������
        [BindProperty]
        public int UserId { get; set; }

        [BindProperty]
        public string FullName { get; set; } = string.Empty;

        [BindProperty]
        public string Email { get; set; } = string.Empty;

        [BindProperty]
        public string Password { get; set; } = string.Empty;

        [BindProperty]
        public string Phone { get; set; } = string.Empty;

        [BindProperty]
        public string UserType { get; set; } = string.Empty;

        [TempData]
        public string? SuccessMessage { get; set; }

        [TempData]
        public string? ErrorMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");
            UserType = HttpContext.Session.GetString("UserType") ?? "";

            if (string.IsNullOrEmpty(sessionUserId) || !int.TryParse(sessionUserId, out int numericUserId))
            {
                return RedirectToPage("/Login");
            }

            UserId = numericUserId;
            await LoadUserProfileAsync();
            return Page();
        }

        // 1. ��� ������ �������� ������� ������ �� ������
        private async Task LoadUserProfileAsync()
        {
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "SELECT FULLNAME, EMAIL, PASSWORD, PHONE, USER_TYPE FROM USERS WHERE USER_ID = :userId";
                OracleCommand cmd = new OracleCommand(query, con);
                cmd.BindByName = true;
                cmd.Parameters.Add(new OracleParameter("userId", UserId));

                try
                {
                    await con.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            FullName = reader["FULLNAME"]?.ToString() ?? "";
                            Email = reader["EMAIL"]?.ToString() ?? "";
                            Password = reader["PASSWORD"]?.ToString() ?? "";
                            Phone = reader["PHONE"]?.ToString() ?? "";
                            UserType = reader["USER_TYPE"]?.ToString() ?? "";
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Error loading profile data: " + ex.Message;
                }
            }
        }

        // 2. ���� ��� ������ �������� �������
        public async Task<IActionResult> OnPostUpdateAsync()
        {
            UserType = HttpContext.Session.GetString("UserType") ?? "";

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = @"
                    UPDATE USERS 
                    SET FULLNAME = :fullname, EMAIL = :email, PASSWORD = :password, PHONE = :phone 
                    WHERE USER_ID = :userId";

                OracleCommand cmd = new OracleCommand(query, con);
                cmd.BindByName = true;

                cmd.Parameters.Add(new OracleParameter("fullname", FullName));
                cmd.Parameters.Add(new OracleParameter("email", Email));
                cmd.Parameters.Add(new OracleParameter("password", Password));
                cmd.Parameters.Add(new OracleParameter("phone", Phone));
                cmd.Parameters.Add(new OracleParameter("userId", UserId));

                try
                {
                    await con.OpenAsync();
                    int rows = await cmd.ExecuteNonQueryAsync();
                    if (rows > 0)
                    {
                        HttpContext.Session.SetString("UserName", FullName);
                        SuccessMessage = "Profile updated successfully!";
                    }
                    else
                    {
                        ErrorMessage = "Failed to update profile.";
                    }
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Database Error: " + ex.Message;
                }
            }
            return RedirectToPage();
        }

        // 3. ���� ��� ������ ������� ��������� �������� ������� (����� �������� �� ��� �������� �� ������)
        public async Task<IActionResult> OnPostDeleteAccountAsync()
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(sessionUserId) || !int.TryParse(sessionUserId, out int numericUserId))
            {
                return RedirectToPage("/Login");
            }

            UserId = numericUserId;
            string userType = (HttpContext.Session.GetString("UserType") ?? "").Trim().ToLower();

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                try
                {
                    await con.OpenAsync();
                }
                catch (Exception ex)
                {
                    ErrorMessage = "Could not connect to database: " + ex.Message;
                    return Page();
                }

                using (OracleTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // [�����] ��� ��� �������� ���� ���� (owner)
                        if (userType == "owner" || userType == "restaurant")
                        {
                            // �. ����� ������ ������ ������ ������ ����� ����� �����
                            try
                            {
                                string makeTablesAvailableOwner = @"
                                    UPDATE TABLES SET STATUS = 'Available'
                                    WHERE RES_ID IN (SELECT RES_ID FROM RESTAURANTS WHERE USER_ID = :userId)";
                                using (OracleCommand cmd = new OracleCommand(makeTablesAvailableOwner, con))
                                {
                                    cmd.BindByName = true;
                                    cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                    await cmd.ExecuteNonQueryAsync();
                                }
                            }
                            catch { }

                            // �. ��� �������� �������� ������� ������ (���� RESERVATION �������)
                            try
                            {
                                string deleteOwnerResSingle = @"
                                    DELETE FROM RESERVATION 
                                    WHERE T_ID IN (
                                        SELECT T_ID FROM TABLES 
                                        WHERE RES_ID IN (SELECT RES_ID FROM RESTAURANTS WHERE USER_ID = :userId)
                                    )";
                                using (OracleCommand cmd = new OracleCommand(deleteOwnerResSingle, con))
                                {
                                    cmd.BindByName = true;
                                    cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                    await cmd.ExecuteNonQueryAsync();
                                }
                            }
                            catch { }

                            // �. ��� �������� ������ �������
                            try
                            {
                                string deleteOwnerTables = "DELETE FROM TABLES WHERE RES_ID IN (SELECT RES_ID FROM RESTAURANTS WHERE USER_ID = :userId)";
                                using (OracleCommand cmd = new OracleCommand(deleteOwnerTables, con))
                                {
                                    cmd.BindByName = true;
                                    cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                    await cmd.ExecuteNonQueryAsync();
                                }
                            }
                            catch { }

                            // �. ��� ������ ����
                            try
                            {
                                string deleteRestaurant = "DELETE FROM RESTAURANTS WHERE USER_ID = :userId";
                                using (OracleCommand cmd = new OracleCommand(deleteRestaurant, con))
                                {
                                    cmd.BindByName = true;
                                    cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                    await cmd.ExecuteNonQueryAsync();
                                }
                            }
                            catch { }
                        }

                        // [������] ��� ��� �������� ���� (Customer)
                        // ���� 1: ����� ���� �������� ���� ��� ��� ������ ������ ����� 'Available'
                        try
                        {
                            string releaseCustomerTables = @"
                                UPDATE TABLES 
                                SET STATUS = 'Available' 
                                WHERE T_ID IN (SELECT T_ID FROM RESERVATION WHERE USER_ID = :userId)";

                            using (OracleCommand cmd = new OracleCommand(releaseCustomerTables, con))
                            {
                                cmd.BindByName = true;
                                cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                await cmd.ExecuteNonQueryAsync();
                            }
                        }
                        catch { }

                        // ���� 2: ��� ��� ����� ����� ������� �� ���� RESERVATION
                        try
                        {
                            string deleteCustomerResSingle = "DELETE FROM RESERVATION WHERE USER_ID = :userId";
                            using (OracleCommand cmd = new OracleCommand(deleteCustomerResSingle, con))
                            {
                                cmd.BindByName = true;
                                cmd.Parameters.Add(new OracleParameter("userId", UserId));
                                await cmd.ExecuteNonQueryAsync();
                            }
                        }
                        catch { }

                        // [������] ������ �������� �������: ��� ���� �������� ������� �� ���� USERS
                        string deleteUser = "DELETE FROM USERS WHERE USER_ID = :userId";
                        using (OracleCommand cmd = new OracleCommand(deleteUser, con))
                        {
                            cmd.BindByName = true;
                            cmd.Parameters.Add(new OracleParameter("userId", UserId));
                            int rows = await cmd.ExecuteNonQueryAsync();

                            if (rows > 0)
                            {
                                await transaction.CommitAsync();
                                HttpContext.Session.Clear(); // ����� ������ ������ ������
                                return RedirectToPage("/Index");
                            }
                            else
                            {
                                transaction.Rollback();
                                ErrorMessage = "Failed to delete account. User not found.";
                                return Page();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ErrorMessage = "An error occurred while deleting your data: " + ex.Message;
                        await LoadUserProfileAsync();
                        return Page();
                    }
                }
            }
        }
    }
}