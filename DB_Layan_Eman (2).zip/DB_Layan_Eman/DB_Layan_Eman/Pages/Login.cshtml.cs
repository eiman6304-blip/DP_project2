using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace DB_Layan_Eman.Pages
{
    public class LoginModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        [BindProperty]
        public string Email { get; set; } = string.Empty;

        [BindProperty]
        public string Password { get; set; } = string.Empty;

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError("", "Please enter both email and password.");
                return Page();
            }

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "SELECT USER_ID, FULLNAME, USER_TYPE FROM USERS WHERE EMAIL = :email AND PASSWORD = :pass";

                OracleCommand cmd = new OracleCommand(query, con);

                // �� ����� ������: ����� �� ���� ����� ���� �������
                cmd.BindByName = true;

                cmd.Parameters.Add(new OracleParameter("email", Email));
                cmd.Parameters.Add(new OracleParameter("pass", Password));

                try
                {
                    await con.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            // ��� �������� �� ��� Session
                            HttpContext.Session.SetString("UserId", reader["USER_ID"]?.ToString() ?? "");
                            HttpContext.Session.SetString("UserName", reader["FULLNAME"]?.ToString() ?? "");
                            HttpContext.Session.SetString("UserEmail", Email);

                            string type = reader["USER_TYPE"]?.ToString() ?? "";
                            HttpContext.Session.SetString("UserType", type);

                            return type == "Owner" ? RedirectToPage("/Cards") : RedirectToPage("/Index");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Database Error: " + ex.Message);
                    return Page();
                }
            }

            ModelState.AddModelError("", "Invalid login attempt.");
            return Page();
        }
    }
}