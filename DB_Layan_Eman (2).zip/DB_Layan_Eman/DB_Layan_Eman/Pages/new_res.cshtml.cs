using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using System;

namespace TableGo.Pages
{
    public class New_ResModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        [BindProperty] public string Name { get; set; } = string.Empty;
        [BindProperty] public string Location { get; set; } = string.Empty;
        [BindProperty] public string Cuisine { get; set; } = string.Empty;
        [BindProperty] public string Phone { get; set; } = string.Empty;
        [BindProperty] public string ImagePath { get; set; } = string.Empty;
        [BindProperty] public int TablesCount { get; set; }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            string ownerEmail = HttpContext.Session.GetString("UserEmail") ?? string.Empty;
            if (string.IsNullOrEmpty(ownerEmail)) return RedirectToPage("Login");

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                try
                {
                    con.Open();
                    using (OracleTransaction trans = con.BeginTransaction())
                    {
                        try
                        {
                            // 1. ��� ��� USER_ID ����� ������� �� ���� USERS �������� ��� Email
                            int userId;
                            string userQuery = "SELECT USER_ID FROM USERS WHERE EMAIL = :email";
                            using (OracleCommand uCmd = new OracleCommand(userQuery, con))
                            {
                                uCmd.BindByName = true;
                                uCmd.Parameters.Add(new OracleParameter("email", ownerEmail));
                                object result = uCmd.ExecuteScalar();

                                if (result == null || result == DBNull.Value)
                                {
                                    ModelState.AddModelError(string.Empty, "�� ��� ������ ��� ���� ������ �� ����� ��������.");
                                    return Page();
                                }
                                userId = Convert.ToInt32(result);
                            }

                            // 2. ����� ������ ���� ��� RES_ID �� ����� ��� USER_ID ����� ������
                            string resQuery = @"INSERT INTO RESTAURANTS (NAME, LOCATION, CUISINE, PHONE_NUMBER, IMAGE_PATH, OWNER_EMAIL, USER_ID) 
                                                VALUES (:name, :loc, :cui, :ph, :img, :email, :userId) 
                                                RETURNING RES_ID INTO :newId";

                            int newResId;
                            using (OracleCommand cmd = new OracleCommand(resQuery, con))
                            {
                                cmd.BindByName = true;
                                cmd.Parameters.Add(new OracleParameter("name", Name));
                                cmd.Parameters.Add(new OracleParameter("loc", Location));
                                cmd.Parameters.Add(new OracleParameter("cui", Cuisine));
                                cmd.Parameters.Add(new OracleParameter("ph", Phone));
                                cmd.Parameters.Add(new OracleParameter("img", string.IsNullOrEmpty(ImagePath) ? "/images/default.jpg" : ImagePath));
                                cmd.Parameters.Add(new OracleParameter("email", ownerEmail));
                                cmd.Parameters.Add(new OracleParameter("userId", userId)); // ��� �� ��� ������ �� ID ������

                                OracleParameter idParam = new OracleParameter("newId", OracleDbType.Int32);
                                idParam.Direction = System.Data.ParameterDirection.Output;
                                cmd.Parameters.Add(idParam);

                                cmd.ExecuteNonQuery();
                                newResId = Convert.ToInt32(idParam.Value.ToString());
                            }

                            // 3. ����� �������� ����� ��� ����� ������ (RES_ID, CAPACITY, STATUS)
                            for (int i = 1; i <= TablesCount; i++)
                            {
                                string tableQuery = "INSERT INTO TABLES (RES_ID, CAPACITY, STATUS) VALUES (:rid, 4, 'Available')";
                                using (OracleCommand tCmd = new OracleCommand(tableQuery, con))
                                {
                                    tCmd.BindByName = true;
                                    tCmd.Parameters.Add(new OracleParameter("rid", newResId));
                                    tCmd.ExecuteNonQuery();
                                }
                            }

                            trans.Commit();
                            return RedirectToPage("Cards");
                        }
                        catch (Exception ex)
                        {
                            trans.Rollback();
                            ModelState.AddModelError(string.Empty, "��� �� ����� SQL: " + ex.Message);
                            return Page();
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "��� �� �������: " + ex.Message);
                    return Page();
                }
            }
        }
    }
}