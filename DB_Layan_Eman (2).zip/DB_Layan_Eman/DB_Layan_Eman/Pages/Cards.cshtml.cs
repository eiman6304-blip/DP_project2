using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;

namespace TableGo.Pages
{
    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string ImagePath { get; set; } = string.Empty;
        public string Cuisine { get; set; } = string.Empty;
        public bool IsOpen { get; set; } = true;
    }

    public class CardsModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        public string OwnerName { get; set; } = "Owner";
        public List<Restaurant> MyRestaurants { get; set; } = new List<Restaurant>();

        public void OnGet()
        {
            OwnerName = HttpContext.Session.GetString("UserName") ?? "Owner";
            string ownerEmail = HttpContext.Session.GetString("UserEmail") ?? "";

            if (string.IsNullOrEmpty(ownerEmail))
            {
                Response.Redirect("/Login");
                return;
            }

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                string query = "SELECT RES_ID, NAME, LOCATION, IMAGE_PATH, CUISINE FROM RESTAURANTS WHERE OWNER_EMAIL = :email";
                OracleCommand cmd = new OracleCommand(query, con);

                // ����� ����� ������ ����� ����� ����������� �������� ���� ���� �� ������
                cmd.BindByName = true;
                cmd.Parameters.Add(new OracleParameter("email", ownerEmail));

                try
                {
                    con.Open();
                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            MyRestaurants.Add(new Restaurant
                            {
                                Id = Convert.ToInt32(reader["RES_ID"]),
                                Name = reader["NAME"].ToString() ?? "",
                                Location = reader["LOCATION"].ToString() ?? "",
                                Cuisine = reader["CUISINE"].ToString() ?? "",

                                // ����� ���� ������ ������� �� ���� ���� ����ɡ ���� ��� ���� ��������
                                ImagePath = reader["IMAGE_PATH"] != DBNull.Value && !string.IsNullOrEmpty(reader["IMAGE_PATH"].ToString())
                                    ? reader["IMAGE_PATH"].ToString()!
                                    : "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4"
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error Loading Owner Restaurants: " + ex.Message);
                }
            }
        }

        public IActionResult OnPostLogout()
        {
            HttpContext.Session.Clear();
            return RedirectToPage("Index");
        }
    }
}