﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace DB_Layan_Eman.Pages
{
    public class IndexModel : PageModel
    {
        private string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xe)));User Id=system;Password=Layan_Eman;";

        public string? UserName { get; set; }
        public string? UserType { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SearchQuery { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? City { get; set; }

        public List<Restaurant> SearchResults { get; set; } = new List<Restaurant>();
        public List<Restaurant> FeaturedRestaurants { get; set; } = new List<Restaurant>();

        public async Task OnGetAsync()
        {
            UserName = HttpContext.Session.GetString("UserName");
            UserType = HttpContext.Session.GetString("UserType");

            // جلب المطاعم المميزة (بدون فلترة)
            FeaturedRestaurants = await GetRestaurantsAsync(null, null);

            // جلب نتائج البحث إذا اختار المستخدم مدينة أو كتب نصاً للبحث
            if (!string.IsNullOrWhiteSpace(SearchQuery) || !string.IsNullOrWhiteSpace(City))
            {
                SearchResults = await GetRestaurantsAsync(SearchQuery, City);
            }
        }

        public IActionResult OnPostLogout()
        {
            HttpContext.Session.Clear();
            return RedirectToPage("/Index");
        }

        private async Task<List<Restaurant>> GetRestaurantsAsync(string? search, string? city)
        {
            var list = new List<Restaurant>();
            using (OracleConnection con = new OracleConnection(connectionString))
            {
                // تم تعديل الاستعلام هنا لجلب IMAGE_PATH بدلاً من IMAGE_URL لأن الأخير قيمته null في قاعدة بياناتك
                string query = "SELECT RES_ID, NAME, LOCATION, CUISINE, IMAGE_PATH FROM RESTAURANTS WHERE 1=1";

                if (!string.IsNullOrWhiteSpace(search))
                    query += " AND (UPPER(NAME) LIKE :search1 OR UPPER(CUISINE) LIKE :search2)";

                if (!string.IsNullOrWhiteSpace(city))
                    query += " AND UPPER(LOCATION) LIKE :city";

                query += " ORDER BY NAME ASC";

                using (OracleCommand cmd = new OracleCommand(query, con))
                {
                    cmd.BindByName = true;

                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        string searchWildcard = $"%{search.ToUpper().Trim()}%";
                        cmd.Parameters.Add(new OracleParameter("search1", searchWildcard));
                        cmd.Parameters.Add(new OracleParameter("search2", searchWildcard));
                    }

                    if (!string.IsNullOrWhiteSpace(city))
                    {
                        // تحويل القيمة المرسلة إلى الأحرف الكبيرة لتتطابق مع UPPER(LOCATION) في أوراكل
                        string cityWildcard = $"%{city.ToUpper().Trim()}%";
                        cmd.Parameters.Add(new OracleParameter("city", cityWildcard));
                    }

                    try
                    {
                        await con.OpenAsync();
                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                list.Add(new Restaurant
                                {
                                    Id = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]),
                                    Name = reader.IsDBNull(1) ? "Unknown" : reader.GetString(1),
                                    Location = reader.IsDBNull(2) ? "N/A" : reader.GetString(2),
                                    Cuisine = reader.IsDBNull(3) ? "General" : reader.GetString(3),
                                    // الاعتماد على العمود الصحيح للصورة لتجنب ظهور كروت فارغة
                                    ImageUrl = reader.IsDBNull(4) ? "/images/default.jpg" : reader.GetString(4)
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine("Oracle DB Error: " + ex.ToString());
                    }
                }
            }
            return list;
        }
    }

    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; } = "Unknown";
        public string Location { get; set; } = "N/A";
        public string Cuisine { get; set; } = "General";
        public string ImageUrl { get; set; } = "/images/default.jpg";
    }
}